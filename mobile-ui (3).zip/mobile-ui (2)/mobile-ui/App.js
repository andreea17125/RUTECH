import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { StatusBar } from "expo-status-bar";
import { useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import LoginScreen from "./screens/Login";
import SignUpScreen from "./screens/SignUpScreen";
import PassengerDashboard from "./screens/PassengerDashboard";
import DriverDashboard from "./screens/DriverDashboard";

const Stack = createNativeStackNavigator();

export default function App() {
  const [initialRoute, setInitialRoute] = useState("Login");
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName={initialRoute}
        screenOptions={{ headerShown: false }}
      >
        <Stack.Screen name="DriverDashboard" component={DriverDashboard} />
        <Stack.Screen
          name="PassengerDashboard"
          component={PassengerDashboard}
        />
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="SignUp" component={SignUpScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
