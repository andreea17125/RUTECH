import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  FlatList,
  Alert,
  Modal,
  TextInput,
  ScrollView,
  PermissionsAndroid,
} from "react-native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useNavigation } from "@react-navigation/native";
import MapView, { Marker } from "react-native-maps";
import * as Location from "expo-location";
import {
  addRoute,
  getGlobalRequests,
  getGlobalReservations,
  updateRequestStatus,
  getRoutes,
  getDriverReservations,
  getRequests,
} from "../utils/SharedStorage";
import QRCode from "react-native-qrcode-svg";
import axios from "axios";
import { LOCALHOST } from "../utils/contants";

const Tab = createBottomTabNavigator();

function CustomHeader({ title, onLogout }) {
  return (
    <View style={styles.header}>
      <Ionicons
        name="bus-outline"
        size={28}
        color="#ffffff"
        style={styles.headerIconLeft}
      />
      <Text style={styles.headerTitle}>{title}</Text>
      <Pressable onPress={onLogout}>
        <Ionicons
          name="log-out-outline"
          size={28}
          color="#ffffff"
          style={styles.headerIconRight}
        />
      </Pressable>
    </View>
  );
}

function Routes() {
  const [routes, setRoutes] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editingRouteId, setEditingRouteId] = useState(null);
  const [newRoute, setNewRoute] = useState({
    departure: "",
    destination: "",
    departureTime: "",
    price: "",
    seats: "",
  });

  useEffect(() => {
    const loadRoutes = async () => {
      try {
        const driverEmail = await AsyncStorage.getItem("userEmail");
        const driverRoutes = await getRoutes(driverEmail);
        setRoutes(driverRoutes);
      } catch (error) {
        console.error("Error loading routes:", error);
        setRoutes([]);
      }
    };

    loadRoutes();
  }, []);

  const handleAddOrUpdateRoute = async () => {
    try {
      if (
        !newRoute.departure ||
        !newRoute.destination ||
        !newRoute.departureTime ||
        !newRoute.price ||
        !newRoute.seats
      ) {
        alert("Please fill in all required fields.");
        return;
      }

      const driverEmail = await AsyncStorage.getItem("userEmail");

      if (editMode) {
       await axios.put(LOCALHOST+"/api/routes/", {
          id: editingRouteId,
          destination: newRoute.destination,
          departure: newRoute.departure,
          price: newRoute.price,
          departureTime: newRoute.departureTime,
          seats: newRoute.seats,
          days: "Monday-Friday",
        }
        )
      
        const routes = await getRoutes(driverEmail);
        setRoutes(routes);
        
      } else {
        await addRoute(newRoute, driverEmail);
        const updatedRoutes = await getRoutes(driverEmail);
        setRoutes(updatedRoutes);
      }

      setNewRoute({
        departure: "",
        destination: "",
        departureTime: "",
        price: "",
        seats: "",
      });
      setEditMode(false);
      setEditingRouteId(null);
      setModalVisible(false);
    } catch (error) {
      console.error("Error adding or updating route:", error);
      alert("An error occurred. Please try again.");
    }
  };

  const handleEditRoute = (route) => {
    setNewRoute(route);
    setEditMode(true);
    setEditingRouteId(route.id);
    setModalVisible(true);
  };

  const handleDeleteRoute = async (id) => {
   await axios.delete(LOCALHOST+`/api/delete-route/${id}/`)
    const driverEmail = await AsyncStorage.getItem("userEmail");
    const updatedRoutes = await getRoutes(driverEmail);
    setRoutes(updatedRoutes);
    Alert.alert("Route Deleted", "The route has been deleted successfully."); 
  };

  const renderRoute = ({ item }) => (
    <View style={styles.routeCard}>
      <Text style={styles.routeText}>
        {" "}
        {item.departure} → {item.destination}
      </Text>
      <Text style={styles.routeText}> {item.departureTime}</Text>
      <Text style={styles.routeText}> {item.price} RON</Text>
      <Text style={styles.routeText}> {item.seats} seats available</Text>
      <View style={styles.routeButtons}>
        <Pressable
          style={styles.editButton}
          onPress={() => handleEditRoute(item)}
        >
          <Text style={styles.editButtonText}>Modify</Text>
        </Pressable>
        <Pressable
          style={styles.deleteButton}
          onPress={() => handleDeleteRoute(item.id)}
        >
          <Ionicons name="trash-outline" size={20} color="#ffffff" />
        </Pressable>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={routes}
        keyExtractor={(item) => item.id}
        renderItem={renderRoute}
        ListEmptyComponent={
          <Text style={styles.noRoutesText}>No routes found.</Text>
        }
      />
      <Pressable style={styles.addButton} onPress={() => setModalVisible(true)}>
        <Ionicons name="add" size={28} color="#ffffff" />
      </Pressable>
      <Modal visible={modalVisible} transparent animationType="slide">
        <ScrollView contentContainerStyle={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>
              {editMode ? "Edit Route" : "Add Route"}
            </Text>
            <TextInput
              style={styles.input}
              placeholder="Departure"
              value={newRoute.departure}
              onChangeText={(text) =>
                setNewRoute({ ...newRoute, departure: text })
              }
            />
            <TextInput
              style={styles.input}
              placeholder="Destination"
              value={newRoute.destination}
              onChangeText={(text) =>
                setNewRoute({ ...newRoute, destination: text })
              }
            />
            <TextInput
              style={styles.input}
              placeholder="Departure Time"
              value={newRoute.departureTime}
              onChangeText={(text) =>
                setNewRoute({ ...newRoute, departureTime: text })
              }
            />
            <TextInput
              style={styles.input}
              placeholder="Price"
              value={newRoute.price}
              onChangeText={(text) => setNewRoute({ ...newRoute, price: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="Seats"
              value={newRoute.seats}
              onChangeText={(text) => setNewRoute({ ...newRoute, seats: text })}
            />
            <Pressable
              style={styles.confirmButton}
              onPress={handleAddOrUpdateRoute}
            >
              <Text style={styles.confirmButtonText}>
                {editMode ? "Update" : "Add"}
              </Text>
            </Pressable>
            <Pressable
              style={styles.cancelButton}
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </Pressable>
          </View>
        </ScrollView>
      </Modal>
    </View>
  );
}

function Requests() {
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    const loadRequests = async () => {
      try {
        const globalRequests = await getGlobalRequests();
        setRequests(globalRequests);
      } catch (error) {
        console.error("Error loading requests:", error);
        setRequests([]);
      }
    };

    loadRequests();
  }, []);

  const handleAcceptRequest = async (id) => {
    try {
      Alert.alert("Request Accepted", "You have accepted the request.");
      await updateRequestStatus(id, "Accepted");
      let newR = getGlobalRequests()
      setRequests(newR);
    } catch (error) {
      console.error("Error accepting request:", error);
      alert("An error occurred while accepting the request.");
    }
  };

  const handleRejectRequest = async (id) => {
    try {
      Alert.alert("Request Rejected", "You have rejected the request.");
      await updateRequestStatus(id, "Rejected");
      const newd = await getGlobalRequests()
      console.log("new requests",newd)
      setRequests(newd);
    } catch (error) {
      console.error("Error rejecting request:", error);
      alert("An error occurred while rejecting the request.");
    }
  };

  const renderRequest = ({ item }) => (
    <View style={styles.requestCard}>
      <Text style={styles.requestText}>From: {item.location}</Text>
      <Text style={styles.requestText}>To: {item.destination}</Text>
      <Text style={styles.requestText}>Time: {item.time}</Text>
      <Text style={styles.requestText}>Status: {item.status || "Pending"}</Text>
      <View style={styles.requestButtons}>
        <Pressable
          style={styles.acceptButton}
          onPress={() => handleAcceptRequest(item.id)}
        >
          <Text style={styles.acceptButtonText}>Accept</Text>
        </Pressable>
        <Pressable
          style={styles.rejectButton}
          onPress={() => handleRejectRequest(item.id)}
        >
          <Text style={styles.rejectButtonText}>Reject</Text>
        </Pressable>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={requests}
        keyExtractor={(item) => item.id}
        renderItem={renderRequest}
        ListEmptyComponent={
          <Text style={styles.noRequestsText}>No requests found.</Text>
        }
      />
    </View>
  );
}

function Reservations() {
  const [reservations, setReservations] = useState([]);

  useEffect(() => {
    const loadReservations = async () => {
      try {
        const driverEmail = await AsyncStorage.getItem("userEmail");
        const driverReservations = await getDriverReservations(driverEmail);
        setReservations(driverReservations);
      } catch (error) {
        console.error("Error loading reservations:", error);
        setReservations([]);
      }
    };

    loadReservations();
  }, []);

  const renderReservation = ({ item }) => (
    <View style={styles.reservationCard}>
      <Text style={styles.reservationText}>
        Seats Reserved: {item.seatsReserved}
      </Text>
      <Text style={styles.reservationText}>From: {item.departure}</Text>
      <Text style={styles.reservationText}>To: {item.destination}</Text>
      <Text style={styles.reservationText}>Time: {item.departureTime}</Text>
      <QRCode value={item.ticketCode} size={100} />
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={reservations}
        keyExtractor={(item, index) => item.id || `reservation-${index}`}
        renderItem={renderReservation}
        ListEmptyComponent={
          <Text style={styles.noReservationsText}>No reservations found.</Text>
        }
      />
    </View>
  );
}

function Map() {
  const [driverLocation, setDriverLocation] = useState(null);

  useEffect(() => {
    const fetchDriverLocation = async () => {
      try {
        // Request permission
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== "granted") {
          alert("Permission denied. Defaulting to Suceava.");
          setDriverLocation({ latitude: 47.6513, longitude: 26.2555 });
          return;
        }

        // Fetch location
        const location = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.High,
          maximumAge: 10000,
          timeout: 15000,
        });

        const { latitude, longitude } = location.coords;
        setDriverLocation({ latitude, longitude });
      } catch (error) {
        console.error("Error fetching location:", error);
        alert("Unable to retrieve location. Defaulting to Suceava.");
        setDriverLocation({ latitude: 47.6513, longitude: 26.2555 });
      }
    };
    const requestLocationPermission = async () => {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          {
            title: "Location Permission",
            message: "This app needs access to your location.",
            buttonNeutral: "Ask Me Later",
            buttonNegative: "Cancel",
            buttonPositive: "OK",
          }
        );
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          fetchDriverLocation()
        } else {
          alert("Location permission denied. Defaulting to Suceava.");
          setDriverLocation({ latitude: 47.6513, longitude: 26.2555 });
        }
      } catch (err) {
        console.warn(err);
        setDriverLocation({ latitude: 47.6513, longitude: 26.2555 });
      }
    };

    requestLocationPermission();
  }, []);

  return (
    <View style={styles.mapContainer}>
      <MapView
        style={styles.map}
        region={
          driverLocation
            ? {
                latitude: driverLocation.latitude,
                longitude: driverLocation.longitude,
                latitudeDelta: 0.05,
                longitudeDelta: 0.05,
              }
            : {
                latitude: 47.6513,
                longitude: 26.2555,
                latitudeDelta: 0.05,
                longitudeDelta: 0.05,
              }
        }
      >
        {driverLocation && (
          <Marker
            coordinate={driverLocation}
            title="Driver Location"
            description="This is your current location."
            pinColor="blue"
          />
        )}
      </MapView>
    </View>
  );
}

export default function DriverDashboard() {
  const navigation = useNavigation();

  const handleLogout = async () => {
    Alert.alert(
      "Confirm Logout",
      "Are you sure you want to log out?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Yes",
          onPress: async () => {
            await AsyncStorage.removeItem("userRole");
            navigation.navigate("Login");
          },
        },
      ],
      { cancelable: true }
    );
  };

  return (
    <>
      <CustomHeader title="Driver Dashboard" onLogout={handleLogout} />
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ color, size }) => {
            let iconName;

            if (route.name === "Routes") {
              iconName = "bus-outline";
            } else if (route.name === "Requests") {
              iconName = "list-outline";
            } else if (route.name === "Reservations") {
              iconName = "people-outline";
            } else if (route.name === "Map") {
              iconName = "map-outline";
            }

            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: "#6AB396",
          tabBarInactiveTintColor: "gray",
          headerShown: false,
        })}
      >
        <Tab.Screen name="Routes" component={Routes} />
        <Tab.Screen name="Requests" component={Requests} />
        <Tab.Screen name="Reservations" component={Reservations} />
        <Tab.Screen name="Map" component={Map} />
      </Tab.Navigator>
    </>
  );
}

const styles = StyleSheet.create({
  header: {
    backgroundColor: "#6AB396",
    height: 60,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 15,
    marginTop: 35,
  },
  headerTitle: {
    color: "#ffffff",
    fontSize: 20,
    fontWeight: "bold",
  },
  headerIconLeft: {
    marginRight: 10,
  },
  headerIconRight: {
    marginLeft: 10,
  },
  container: {
    flex: 1,
    backgroundColor: "#a7d7c5",
    padding: 20,
  },
  routeCard: {
    backgroundColor: "#ffffff",
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "#6AB396",
  },
  routeText: {
    fontSize: 16,
    color: "#595959",
    marginBottom: 5,
  },
  routeButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 10,
  },
  editButton: {
    backgroundColor: "#6AB396",
    borderRadius: 10,
    padding: 10,
    alignItems: "center",
    flex: 1,
    marginRight: 5,
  },
  editButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
  },
  deleteButton: {
    backgroundColor: "#ff5c5c",
    borderRadius: 10,
    padding: 10,
    alignItems: "center",
    flex: 1,
    marginLeft: 5,
  },
  noRoutesText: {
    textAlign: "center",
    color: "#595959",
    marginTop: 20,
  },
  addButton: {
    position: "absolute",
    bottom: 20,
    right: 20,
    backgroundColor: "#6AB396",
    borderRadius: 50,
    width: 60,
    height: 60,
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
  },
  modalContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
  },
  modalContent: {
    backgroundColor: "#ffffff",
    borderRadius: 20,
    padding: 20,
    width: "90%",
    alignItems: "center",
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#6AB396",
    marginBottom: 20,
  },
  input: {
    backgroundColor: "#f9f9f9",
    borderRadius: 10,
    padding: 10,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: "#6AB396",
    width: "100%",
    fontSize: 16,
    color: "#595959",
  },
  confirmButton: {
    backgroundColor: "#6AB396",
    borderRadius: 10,
    padding: 10,
    alignItems: "center",
    marginTop: 10,
    width: "100%",
  },
  confirmButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
    fontSize: 16,
  },
  cancelButton: {
    backgroundColor: "#ff5c5c",
    borderRadius: 10,
    padding: 10,
    alignItems: "center",
    marginTop: 10,
    width: "100%",
  },
  cancelButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
    fontSize: 16,
  },
  requestCard: {
    backgroundColor: "#ffffff",
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "#6AB396",
  },
  requestText: {
    fontSize: 16,
    color: "#595959",
    marginBottom: 5,
  },
  requestButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 10,
  },
  acceptButton: {
    backgroundColor: "#6AB396",
    borderRadius: 10,
    padding: 10,
    alignItems: "center",
    flex: 1,
    marginRight: 5,
  },
  acceptButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
  },
  rejectButton: {
    backgroundColor: "#ff5c5c",
    borderRadius: 10,
    padding: 10,
    alignItems: "center",
    flex: 1,
    marginLeft: 5,
  },
  rejectButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
  },
  reservationCard: {
    backgroundColor: "#ffffff",
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "#6AB396",
    alignItems: "center",
  },
  reservationText: {
    fontSize: 16,
    color: "#595959",
    marginBottom: 5,
  },
  totalSeatsText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#595959",
    marginBottom: 15,
  },
  noReservationsText: {
    textAlign: "center",
    color: "#595959",
    marginTop: 20,
  },
  mapContainer: {
    flex: 1,
    backgroundColor: "#a7d7c5",
  },
  map: {
    flex: 1,
  },
  profileCard: {
    backgroundColor: "#ffffff",
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "#6AB396",
  },
  profileText: {
    fontSize: 16,
    color: "#595959",
    marginBottom: 5,
  },
  editProfileButton: {
    backgroundColor: "#6AB396",
    borderRadius: 10,
    padding: 10,
    alignItems: "center",
    marginTop: 10,
    width: "100%",
  },
  editProfileButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
    fontSize: 16,
  },
});
