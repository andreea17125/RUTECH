import { View, Text, TextInput, StyleSheet, Pressable } from 'react-native'; 
import React, { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage'; 
import { findUser, logUsersToTerminal } from '../utils/UserStorage';

export default function LoginScreen() {
    const navigation = useNavigation();
    const [isPressed, setIsPressed] = useState(false); 
    const [email, setEmail] = useState(''); 
    const [password, setPassword] = useState(''); 

    const handleLogin = async () => {
        try {
            const normalizedEmail = email.trim().toLowerCase();
            const user = await findUser(normalizedEmail, password);

            if (!user) {
                alert('Invalid email or password. Please try again.');
                return;
            }

            await logUsersToTerminal();

          
            const defaultLocation = { latitude: 47.6333, longitude: 25.8667 };
            await AsyncStorage.setItem('userRole', user.role);
            await AsyncStorage.setItem('userLocation', JSON.stringify(defaultLocation));

        
            if (user.role === 'Driver') {
                navigation.navigate('DriverDashboard');
            } else if (user.role === 'Passenger') {
                navigation.navigate('PassengerDashboard');
            }
        } catch (error) {
            console.error('Error during login:', error);
            alert('An error occurred. Please try again.');
        }
    };

    return (
        <View style={styles.container}>
            <StatusBar style="light" />
            <View style={styles.contentContainer}>
                <View style={styles.titleContainer}>
                    <Text style={styles.appTitle}>RUTECH</Text>
                </View>
                <View style={styles.inputContainer}>
                    <View style={styles.inputWrapper}>
                        <Ionicons name="mail-outline" size={24} color="#6AB396" style={styles.icon} />
                        <TextInput
                            style={styles.input}
                            placeholder="Email"
                            placeholderTextColor="gray"
                            value={email}
                            onChangeText={setEmail}
                        />
                    </View>
                    <View style={styles.inputWrapper}>
                        <Ionicons name="lock-closed-outline" size={24} color="#6AB396" style={styles.icon} />
                        <TextInput
                            style={styles.input}
                            placeholder="Password"
                            placeholderTextColor="gray"
                            secureTextEntry
                            value={password}
                            onChangeText={setPassword}
                        />
                    </View>
                    <Pressable
                        style={({ pressed }) => [
                            styles.loginButton,
                            pressed || isPressed ? styles.loginButtonHover : null,
                        ]}
                        onPress={handleLogin}
                        onPressIn={() => setIsPressed(true)}
                        onPressOut={() => setIsPressed(false)}
                    >
                        <Text style={styles.loginButtonText}>Login</Text>
                    </Pressable>
                    <View style={styles.signUpContainer}>
                        <Text style={styles.signupText}>
                            Don't have an account?{' '}
                            <Text
                                style={styles.signupLink}
                                onPress={() => navigation.navigate('SignUp')}
                            >
                                Sign Up
                            </Text>
                        </Text>
                    </View>
                </View>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#a7d7c5',
        justifyContent: 'center',
        padding: 20,
    },
    contentContainer: {
        alignItems: 'center',
        paddingTop: 80, 
    },
    titleContainer: {
        alignItems: 'center',
    },
    appTitle: {
        fontSize: 50,
        color: '#84c7ae',
        marginBottom: 35,
        textAlign: 'center',
        fontWeight: 'bold',
    },
    inputContainer: {
        width: '100%',
        alignItems: 'center',
        marginBottom: 20,
    },
    inputWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'rgba(255, 255, 255, 0.56)',
        borderRadius: 20,
        paddingHorizontal: 15,
        height: 50,
        width: '90%',
        marginBottom: 30,
        borderWidth: 1,
        borderColor: '#6AB396',
    },
    icon: {
        color: '#6AB396',
        marginRight: 10,
    },
    input: {
        flex: 1,
        fontFamily: 'Roboto',
        fontSize: 14,
        color: '#595959',
    },
    loginButton: {
        width: '60%',
        maxWidth: 200,
        height: 50,
        backgroundColor: '#6AB396',
        borderRadius: 30,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 25,
        boxShadow: '0 4px 10px rgba(0, 0, 0, 0.15)',
    },
    loginButtonHover: {
        backgroundColor: '#5fa686',
    },
    loginButtonText: {
        color: '#ffffff',
        fontFamily: 'Roboto',
        fontWeight: '700',
        fontSize: 25,
    },
    signUpContainer: {
        marginTop: 20,
        alignItems: 'center',
    },
    signupText: {
        textAlign: 'center',
        fontFamily: 'Roboto',
        fontSize: 16,
        color: '#595959',
        marginTop: 15,
    },
    signupLink: {
        color: '#6AB396',
        fontWeight: '700',
        textDecorationLine: 'underline',
    },
});
