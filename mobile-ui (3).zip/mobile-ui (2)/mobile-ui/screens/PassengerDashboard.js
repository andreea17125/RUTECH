import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  Pressable,
  FlatList,
  Alert,
  TouchableOpacity,
  Modal,
  PermissionsAndroid,
} from "react-native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useNavigation } from "@react-navigation/native";
import QRCode from "react-native-qrcode-svg";
import locations from "../assets/locations";
import MapView, { Marker, Polyline } from "react-native-maps";
import { Picker } from "@react-native-picker/picker";
import {
  getAllRoutes,
  addRequest,
  addReservation,
  getReservations,
  getRequests,
  deleteReservation,
  deleteRequest,
} from "../utils/SharedStorage"; // Import shared storage utilities
import * as Location from "expo-location";
import axios from "axios";
import { LOCALHOST } from "../utils/contants";

const Tab = createBottomTabNavigator();

function CustomHeader({ title, onLogout }) {
  return (
    <View style={styles.header}>
      <Ionicons
        name="bus-outline"
        size={28}
        color="#ffffff"
        style={styles.headerIconLeft}
      />
      <Text style={styles.headerTitle}>{title}</Text>
      <Pressable onPress={onLogout}>
        <Ionicons
          name="log-out-outline"
          size={28}
          color="#ffffff"
          style={styles.headerIconRight}
        />
      </Pressable>
    </View>
  );
}

function SearchTransport({ onReserve, refreshTrigger }) {
  const [departure, setDeparture] = useState("");
  const [destination, setDestination] = useState("");
  const [departureTime, setDepartureTime] = useState("");
  const [availableTrips, setAvailableTrips] = useState([]);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearchTrips = async () => {
    const getAllRoutes = async () => {
  try {
    const routes = await axios.get(LOCALHOST +"/api/routes/" )
    return routes.data.message
  } catch (error) {
    console.error("Error retrieving all routes:", error);
    return [];
  }
};

    const routes = await getAllRoutes();
    const filteredTrips = routes.filter(
      (route) =>
        route.departure.toLowerCase().includes(departure.toLowerCase()) &&
        route.destination.toLowerCase().includes(destination.toLowerCase()) &&
        (!departureTime || route.departureTime === departureTime)
    );
    setAvailableTrips(filteredTrips);
    setHasSearched(true);
  };

  useEffect(() => {
    if (hasSearched) {
      handleSearchTrips();
    }
  }, [refreshTrigger]);

  const renderTrip = ({ item }) => (
    <View style={styles.tripCard}>
      <Text style={styles.tripText}>
        {" "}
        {item.departure} → {item.destination}
      </Text>
      <Text style={styles.tripText}> {item.departureTime}</Text>
      <Text style={styles.tripText}> {item.price} RON</Text>
      <Text style={styles.tripText}> {item.seats} seats available</Text>
      <Text style={styles.tripText}> {item.days || "No day specified"}</Text>
      <Pressable style={styles.reserveButton} onPress={() => onReserve(item)}>
        <Text style={styles.reserveButtonText}>Reserve</Text>
      </Pressable>
    </View>
  );

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Departure"
        value={departure}
        onChangeText={setDeparture}
      />
      <TextInput
        style={styles.input}
        placeholder="Destination"
        value={destination}
        onChangeText={setDestination}
      />
      <TextInput
        style={styles.input}
        placeholder="Departure Time"
        value={departureTime}
        onChangeText={setDepartureTime}
      />
      <Pressable style={styles.searchButton} onPress={handleSearchTrips}>
        <Text style={styles.searchButtonText}>Search</Text>
      </Pressable>
      {hasSearched ? (
        <FlatList
          data={availableTrips}
          keyExtractor={(item) => item.id}
          renderItem={renderTrip}
          ListEmptyComponent={
            <Text style={styles.noTripsText}>
              No trips found matching your criteria.
            </Text>
          }
          style={styles.availableTripsList}
        />
      ) : (
        <View style={styles.initialMessageContainer}>
          <Text style={styles.initialMessageText}>
            Enter search criteria and click Search to find available trips.
          </Text>
        </View>
      )}
    </View>
  );
}

function Requests() {
  const [modalVisible, setModalVisible] = useState(false);
  const [requestLocation, setRequestLocation] = useState("");
  const [requestDestination, setRequestDestination] = useState("");
  const [requestTime, setRequestTime] = useState("");
  const [rideRequests, setRideRequests] = useState([]);

  useEffect(() => {
    const loadRequests = async () => {
      try {
        const userEmail = await AsyncStorage.getItem("userEmail");
        const passengerRequests = await getRequests(userEmail);
        setRideRequests(passengerRequests);
      } catch (error) {
        console.error("Error loading requests:", error);
        setRideRequests([]);
      }
    };

    loadRequests();
  }, []);

  const handleRequestRide = async () => {
    if (!requestLocation || !requestDestination || !requestTime) {
      alert("Please fill in all fields.");
      return;
    }

    const userEmail = await AsyncStorage.getItem("userEmail");
    const newRequest = {
      location: requestLocation,
      destination: requestDestination,
      time: requestTime,
      passengerEmail: userEmail,
    };

    await addRequest(newRequest);
    setRequestLocation("");
    setRequestDestination("");
    setRequestTime("");
    setModalVisible(false);

    const passengerRequests = await getRequests(userEmail);
    setRideRequests(passengerRequests);
  };

  const handleDeleteRequest = async (requestId) => {
    try {
      console.log("Deleting request with ID:", requestId);
      const success = await axios.delete(LOCALHOST+`/api/passager/${requestId}/`);
      if (success) {
        Alert.alert("Success", "Request deleted successfully");

        const userEmail = await AsyncStorage.getItem("userEmail");
        const passengerRequests = await getRequests(userEmail);
        setRideRequests(passengerRequests);
      } else {
        Alert.alert("Error", "Failed to delete request");
      }
    } catch (error) {
      console.error("Error deleting request:", error);
      Alert.alert("Error", "An error occurred while deleting the request");
    }
  };

  const renderRideRequest = ({ item }) => (
    console.log('ITEM',item),
    <View style={styles.rideRequestCard}>
      <Text style={styles.rideRequestText}>From: {item.location}</Text>
      <Text style={styles.rideRequestText}>To: {item.destination}</Text>
      <Text style={styles.rideRequestText}>Time: {item.time}</Text>
      <Text style={styles.rideRequestText}>
        Status: {item.rejected == true  ? "Rejected" : item.accepted ?  "Accepted" : "Pending"}
      </Text>
      <Pressable
        style={styles.deleteButton}
        onPress={() => {
          Alert.alert(
            "Delete Request",
            "Are you sure you want to delete this request?",
            [
              {
                text: "Cancel",
                style: "cancel",
              },
              {
                text: "Delete",
                onPress: () => handleDeleteRequest(item.id),
                style: "destructive",
              },
            ]
          );
        }}
      >
        <Text style={styles.deleteButtonText}>Delete Request</Text>
      </Pressable>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={rideRequests}
        keyExtractor={(item) => item.id}
        renderItem={renderRideRequest}
        ListEmptyComponent={
          <Text style={styles.noRequestsText}>No requests found.</Text>
        }
      />
      <Pressable style={styles.addButton} onPress={() => setModalVisible(true)}>
        <Ionicons name="add" size={28} color="#ffffff" />
      </Pressable>
      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Request a Ride</Text>
            <TextInput
              style={styles.input}
              placeholder="Location"
              value={requestLocation}
              onChangeText={setRequestLocation}
            />
            <TextInput
              style={styles.input}
              placeholder="Destination"
              value={requestDestination}
              onChangeText={setRequestDestination}
            />
            <TextInput
              style={styles.input}
              placeholder="Time"
              value={requestTime}
              onChangeText={setRequestTime}
            />
            <Pressable style={styles.confirmButton} onPress={handleRequestRide}>
              <Text style={styles.confirmButtonText}>Submit</Text>
            </Pressable>
            <Pressable
              style={styles.cancelButton}
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function Reservations() {
  const [reservations, setReservations] = useState([]);

  const loadReservations = async () => {
    try {
      const userEmail = await AsyncStorage.getItem("userEmail");
      if (!userEmail) {
        console.error("No user email found");
        return;
      }
      const userReservations = await getReservations(userEmail);
      setReservations(userReservations);
    } catch (error) {
      console.error("Error loading reservations:", error);
    }
  };

  useEffect(() => {
    loadReservations();
  }, []);

  const handleDeleteReservation = async (reservationId) => {
    try {
      const success = await deleteReservation(reservationId);
      const passagerEmail = await AsyncStorage.getItem("userEmail");
      const passengerReservations = await getReservations(passagerEmail);
      setReservations(passengerReservations);
      if (success) {
        Alert.alert("Success", "Reservation deleted successfully");
        loadReservations();
      } else {
        Alert.alert("Error", "Failed to delete reservation");
      }
    } catch (error) {
      console.error("Error deleting reservation:", error);
      Alert.alert("Error", "An error occurred while deleting the reservation");
    }
  };

  const renderReservation = ({ item }) => (
    <View style={styles.reservationCard}>
      <Text style={styles.reservationText}>From: {item.departure}</Text>
      <Text style={styles.reservationText}>To: {item.destination}</Text>
      <Text style={styles.reservationText}>Time: {item.departureTime}</Text>
      <Text style={styles.reservationText}>Seats: {item.seatsReserved}</Text>
      <Text style={styles.reservationText}>
        Day: {item.days || "No day specified"}
      </Text>
      <Text style={styles.reservationText}>Ticket Code: {item.ticketCode}</Text>
      <View style={styles.qrCodeContainer}>
        <QRCode value={item.ticketCode} size={100} />
      </View>
      <Pressable
        style={styles.deleteButton}
        onPress={() => {
          Alert.alert(
            "Delete Reservation",
            "Are you sure you want to delete this reservation?",
            [
              {
                text: "Cancel",
                style: "cancel",
              },
              {
                text: "Delete",
                onPress: () => handleDeleteReservation(item.id),
                style: "destructive",
              },
            ]
          );
        }}
      >
        <Text style={styles.deleteButtonText}>Delete Reservation</Text>
      </Pressable>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={reservations}
        keyExtractor={(item) => item.id}
        renderItem={renderReservation}
        ListEmptyComponent={
          <Text style={styles.noReservationsText}>No reservations found.</Text>
        }
      />
    </View>
  );
}

export default function PassengerDashboard() {
  const navigation = useNavigation();
  const [reservations, setReservations] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedTrip, setSelectedTrip] = useState(null);
  const [seatsToReserve, setSeatsToReserve] = useState("");
  const [searchRefreshTrigger, setSearchRefreshTrigger] = useState(0);

  const handleLogout = async () => {
    Alert.alert(
      "Confirm Logout",
      "Are you sure you want to log out?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Yes",
          onPress: async () => {
            await AsyncStorage.removeItem("userRole");
            navigation.navigate("Login");
          },
        },
      ],
      { cancelable: true }
    );
  };

  const handleReserve = (trip) => {
    setSelectedTrip(trip);
    setModalVisible(true);
  };

  const confirmReservation = async () => {
    if (!seatsToReserve || isNaN(seatsToReserve) || seatsToReserve <= 0) {
      alert("Please enter a valid number of seats.");
      return;
    }

    if (seatsToReserve > selectedTrip.seats) {
      alert("Not enough seats available.");
      return;
    }

    const userEmail = await AsyncStorage.getItem("userEmail");
    const newReservation = {
      ...selectedTrip,
      seatsReserved: parseInt(seatsToReserve, 10),
      passengerEmail: userEmail,
      routeId: selectedTrip.id,
      driverId: selectedTrip.driverId,
      days: selectedTrip.days,
    };

    await addReservation(newReservation);
    setModalVisible(false);
    alert(
      "Reservation confirmed! Your QR code is now available in the Reservations tab."
    );

    const passengerReservations = await getReservations(userEmail);
    setReservations(passengerReservations);

    setSearchRefreshTrigger((prev) => prev + 1);
  };

  return (
    <>
      <CustomHeader title="Passenger Dashboard" onLogout={handleLogout} />
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ color, size }) => {
            let iconName;

            if (route.name === "SearchTransport") {
              iconName = "search-outline";
            } else if (route.name === "Requests") {
              iconName = "list-outline";
            } else if (route.name === "Reservations") {
              iconName = "qr-code-outline";
            } else if (route.name === "Map") {
              iconName = "map-outline";
            }

            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: "#6AB396",
          tabBarInactiveTintColor: "gray",
          headerShown: false,
        })}
      >
        <Tab.Screen
          name="SearchTransport"
          children={() => (
            <SearchTransport
              onReserve={handleReserve}
              refreshTrigger={searchRefreshTrigger}
            />
          )}
          options={{ title: "Search" }}
        />
        <Tab.Screen
          name="Requests"
          children={() => <Requests />}
          options={{ title: "Requests" }}
        />
        <Tab.Screen
          name="Reservations"
          children={() => <Reservations />}
          options={{ title: "Reservations" }}
        />
        <Tab.Screen name="Map" component={Map} options={{ title: "Map" }} />
      </Tab.Navigator>

      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Reserve Seats</Text>
            <TextInput
              style={styles.input}
              placeholder="Number of seats"
              keyboardType="numeric"
              value={seatsToReserve}
              onChangeText={setSeatsToReserve}
            />
            <Pressable
              style={styles.confirmButton}
              onPress={confirmReservation}
            >
              <Text style={styles.confirmButtonText}>Confirm</Text>
            </Pressable>
            <Pressable
              style={styles.cancelButton}
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </>
  );
}

function Map() {
  const [passengerLocation, setPassengerLocation] = useState(null);

  useEffect(() => {
    const requestLocationPermission = async () => {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          {
            title: "Location Permission",
            message: "This app needs access to your location.",
            buttonNeutral: "Ask Me Later",
            buttonNegative: "Cancel",
            buttonPositive: "OK",
          }
        );
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          const fetchPassengerLocation = async () => {
            try {
              // Request permission to access location
              const { status } =
                await Location.requestForegroundPermissionsAsync();
              if (status !== "granted") {
                alert("Permission denied. Defaulting to Suceava.");
                setPassengerLocation({ latitude: 47.6513, longitude: 26.2555 });
                return;
              }

              // Fetch current location
              const location = await Location.getCurrentPositionAsync({
                accuracy: Location.Accuracy.High,
                maximumAge: 10000,
                timeout: 15000,
              });

              const { latitude, longitude } = location.coords;
              setPassengerLocation({ latitude, longitude });
            } catch (error) {
              console.error("Error fetching location:", error);
              alert("Unable to retrieve location. Defaulting to Suceava.");
              setPassengerLocation({ latitude: 47.6513, longitude: 26.2555 });
            }
          };
        } else {
          alert("Location permission denied. Defaulting to Suceava.");
          setPassengerLocation({ latitude: 47.6513, longitude: 26.2555 });
        }
      } catch (err) {
        console.warn(err);
        setPassengerLocation({ latitude: 47.6513, longitude: 26.2555 });
      }
    };

    requestLocationPermission();
  }, []);

  return (
    <View style={styles.mapContainer}>
      <MapView
        style={styles.map}
        region={
          passengerLocation
            ? {
                latitude: passengerLocation.latitude,
                longitude: passengerLocation.longitude,
                latitudeDelta: 0.05,
                longitudeDelta: 0.05,
              }
            : {
                latitude: 47.6513,
                longitude: 26.2555,
                latitudeDelta: 0.05,
                longitudeDelta: 0.05,
              }
        }
      >
        {passengerLocation && (
          <Marker
            coordinate={passengerLocation}
            title="Passenger Location"
            description="This is your current location."
            pinColor="green"
          />
        )}
      </MapView>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    backgroundColor: "#6AB396",
    height: 60,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 15,
    marginTop: 35,
  },
  headerTitle: {
    color: "#ffffff",
    fontSize: 20,
    fontWeight: "bold",
  },
  headerIconLeft: {
    marginRight: 10,
  },
  headerIconRight: {
    marginLeft: 10,
  },
  container: {
    flex: 1,
    backgroundColor: "#a7d7c5",
    padding: 20,
  },
  searchContainer: {
    marginBottom: 20,
  },
  input: {
    backgroundColor: "#f9f9f9",
    borderRadius: 10,
    padding: 10,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: "#6AB396",
    width: "100%",
    fontSize: 16,
    color: "#595959",
  },
  searchButton: {
    backgroundColor: "#6AB396",
    borderRadius: 10,
    padding: 10,
    alignItems: "center",
  },
  searchButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
  },
  tripCard: {
    backgroundColor: "#ffffff",
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "#6AB396",
  },
  tripText: {
    fontSize: 16,
    color: "#595959",
    marginBottom: 5,
  },
  noTripsText: {
    textAlign: "center",
    color: "#595959",
    marginTop: 20,
  },
  reserveButton: {
    backgroundColor: "#6AB396",
    borderRadius: 10,
    padding: 10,
    alignItems: "center",
    marginTop: 10,
  },
  reserveButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
  },
  reservationCard: {
    backgroundColor: "#ffffff",
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "#6AB396",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  reservationHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    borderBottomWidth: 1,
    borderBottomColor: "#e0e0e0",
    paddingBottom: 10,
    marginBottom: 10,
  },
  reservationTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#6AB396",
    marginBottom: 5,
  },
  reservationInfo: {
    width: "100%",
    marginBottom: 15,
  },
  reservationText: {
    fontSize: 16,
    color: "#595959",
    marginBottom: 8,
  },
  noReservationsText: {
    textAlign: "center",
    color: "#595959",
    marginTop: 20,
  },
  deleteButton: {
    backgroundColor: "#ff4444",
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
    alignSelf: "stretch",
    alignItems: "center",
  },
  deleteButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
    fontSize: 16,
  },
  modalContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
  },
  modalContent: {
    backgroundColor: "#ffffff",
    borderRadius: 20,
    padding: 20,
    width: "90%",
    alignItems: "center",
    elevation: 10,
    borderWidth: 1,
    borderColor: "#6AB396",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#6AB396",
    marginBottom: 20,
  },
  confirmButton: {
    backgroundColor: "#6AB396",
    borderRadius: 10,
    padding: 10,
    alignItems: "center",
    marginTop: 10,
    width: "100%",
  },
  confirmButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
    fontSize: 16,
  },
  cancelButton: {
    backgroundColor: "#ff5c5c",
    borderRadius: 10,
    padding: 10,
    alignItems: "center",
    marginTop: 10,
    width: "100%",
  },
  cancelButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
    fontSize: 16,
  },
  gradientButton: {
    backgroundColor: "#6AB396",
    borderRadius: 30,
    paddingVertical: 12,
    paddingHorizontal: 20,
    alignItems: "center",
    marginTop: 10,
    width: "100%",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
  },
  gradientButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
    fontSize: 16,
  },
  addButton: {
    position: "absolute",
    bottom: 20,
    right: 20,
    backgroundColor: "#6AB396",
    borderRadius: 50,
    width: 60,
    height: 60,
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
  },
  rideRequestCard: {
    backgroundColor: "#ffffff",
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "#6AB396",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
  },
  rideRequestHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  rideRequestText: {
    fontSize: 16,
    color: "#595959",
    marginBottom: 5,
  },
  mapContainer: {
    flex: 1,
    backgroundColor: "#a7d7c5",
  },
  map: {
    flex: 1,
  },
  dropdownWrapper: {
    backgroundColor: "#f9f9f9",
    borderRadius: 10,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: "#6AB396",
    width: "100%",
  },
  dropdown: {
    width: "100%",
    color: "#595959",
  },
  availableTripsList: {
    marginTop: 10,
  },
  initialMessageContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  initialMessageText: {
    color: "#595959",
    fontSize: 16,
    textAlign: "center",
  },
  qrCodeContainer: {
    marginTop: 15,
    alignItems: "center",
    padding: 10,
    backgroundColor: "#f9f9f9",
    borderRadius: 8,
  },
});
