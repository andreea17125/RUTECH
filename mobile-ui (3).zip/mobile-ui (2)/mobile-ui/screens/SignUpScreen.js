import { View, Text, TextInput, StyleSheet, Pressable } from 'react-native';
import React, { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons'; 
import { Picker } from '@react-native-picker/picker'; 
import { addUser, getUsers, logUsersToTerminal } from '../utils/UserStorage';

export default function SignUpScreen() {
    const navigation = useNavigation();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('');
    const [isPressed, setIsPressed] = useState(false);

    const handleSignUp = async () => {
        try {
            if (!email || !password || !role) {
                alert('Please fill in all fields.');
                return;
            }

           
            const normalizedEmail = email.trim().toLowerCase();

           
            const users = await getUsers();

            if (users.some((user) => user.email === normalizedEmail)) {
                alert('This email is already registered.');
                return;
            }

            
            const newUser = { email: normalizedEmail, password, role };
            await addUser(newUser);

            await logUsersToTerminal();

            alert('Account created successfully!');
            navigation.navigate('Login'); 
        } catch (error) {
            console.error('Error during sign-up:', error);
            alert('An error occurred. Please try again.');
        }
    };

    return (
        <View style={styles.container}>
            <StatusBar style="light" />
            <View style={styles.contentContainer}>
                <Text style={styles.appTitle}>RUTECH</Text>
                <View style={styles.inputContainer}>
                    <View style={styles.inputWrapper}>
                        <Ionicons name="mail-outline" size={20} style={styles.icon} />
                        <TextInput
                            style={styles.input}
                            placeholder="Email"
                            placeholderTextColor="gray"
                            value={email}
                            onChangeText={setEmail}
                        />
                    </View>
                    <View style={styles.inputWrapper}>
                        <Ionicons name="lock-closed-outline" size={20} style={styles.icon} />
                        <TextInput
                            style={styles.input}
                            placeholder="Password"
                            placeholderTextColor="gray"
                            secureTextEntry
                            value={password}
                            onChangeText={setPassword}
                        />
                    </View>
                    <View style={styles.dropdownWrapper}>
                        <Ionicons name="person-outline" size={20} style={styles.icon} />
                        <Picker
                            selectedValue={role}
                            onValueChange={(itemValue) => setRole(itemValue)}
                            style={styles.dropdown}
                            dropdownIconColor="gray"
                        >
                            <Picker.Item label="Select a role" value="" enabled={false} />
                            <Picker.Item label="Driver" value="Driver" />
                            <Picker.Item label="Passenger" value="Passenger" />
                        </Picker>
                    </View>
                </View>
                <Pressable
                    style={({ pressed }) => [
                        styles.signupButton,
                        pressed || isPressed ? styles.signupButtonHover : null,
                    ]}
                    onPress={handleSignUp}
                    onPressIn={() => setIsPressed(true)}
                    onPressOut={() => setIsPressed(false)}
                >
                    <Text style={styles.signupButtonText}>Sign Up</Text>
                </Pressable>
                <Text style={styles.signupText}>
                    Already have an account?{' '}
                    <Text
                        style={styles.signupLink}
                        onPress={() => navigation.navigate('Login')}
                    >
                        Login
                    </Text>
                </Text>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#a7d7c5',
        justifyContent: 'center',
        padding: 20,
    },
    contentContainer: {
        alignItems: 'center',
        paddingTop: 80, 
    },
    titleContainer: {
        alignItems: 'center',
    },
    appTitle: {
        fontSize: 50,
        color: '#84c7ae',
        marginBottom: 35,
        textAlign: 'center',
        fontWeight: 'bold',
    },
    inputContainer: {
        width: '100%',
        alignItems: 'center',
        marginBottom: 20,
    },
    inputWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'rgba(255, 255, 255, 0.56)',
        borderRadius: 20,
        paddingHorizontal: 15,
        height: 50,
        width: '90%',
        marginBottom: 20,
        borderWidth: 1,
        borderColor: '#6AB396',
    },
    icon: {
        color: '#6AB396',
        marginRight: 10,
    },
    input: {
        flex: 1,
        fontFamily: 'Roboto',
        fontSize: 14,
        color: '#595959',
    },
    dropdownWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'rgba(255, 255, 255, 0.56)',
        borderRadius: 20,
        paddingHorizontal: 15,
        height: 50,
        width: '90%',
        marginBottom: 20,
        borderWidth: 1,
        borderColor: '#6AB396',
    },
    dropdown: {
        flex: 1,
        color: '#595959',
        backgroundColor: 'transparent',
    },
    signupButton: {
        width: '60%',
        maxWidth: 200,
        height: 50,
        backgroundColor: '#6AB396',
        borderRadius: 30,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 15,
        boxShadow: '0 4px 10px rgba(0, 0, 0, 0.15)',
    },
    signupButtonHover: {
        backgroundColor: '#5fa686',
    },
    signupButtonText: {
        color: '#ffffff',
        fontFamily: 'Roboto',
        fontWeight: '700',
        fontSize: 25,
    },
    signupText: {
        textAlign: 'center',
        fontFamily: 'Roboto',
        fontSize: 16,
        color: '#595959', 
        marginTop: 30,
    },
    signupLink: {
        color: '#6AB396', 
        fontWeight: '700', 
        textDecorationLine: 'underline',
    },
});
