import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";
import { LOCALHOST } from "./contants";

const ROUTES_KEY = "routes";
const REQUESTS_KEY = "requests";
const RESERVATIONS_KEY = "reservations";
const GLOBAL_REQUESTS_KEY = "global_requests";
const GLOBAL_RESERVATIONS_KEY = "global_reservations";
const ALL_ROUTES_KEY = "all_routes";

export const getRoutes = async (driverEmail) => {
  try {
    const routesJSON = await axios.get(
      LOCALHOST + `/api/route-for-driver/${driverEmail}/`
    );
    return routesJSON.data.message;
  } catch (error) {
    console.error("Error retrieving routes:", error);
    return [];
  }
};

export const getAllRoutes = async () => {
  try {
    const keys = await AsyncStorage.getAllKeys();

    const routeKeys = keys.filter((key) => key.startsWith(`${ROUTES_KEY}_`));

    const routeData = await AsyncStorage.multiGet(routeKeys);

    let allRoutes = [];
    routeData.forEach(([key, value]) => {
      if (value) {
        const routes = JSON.parse(value);

        const driverEmail = key.replace(`${ROUTES_KEY}_`, "");
        const routesWithDriver = routes.map((route) => ({
          ...route,
          driverId: driverEmail,
        }));
        allRoutes = [...allRoutes, ...routesWithDriver];
      }
    });

    return allRoutes;
  } catch (error) {
    console.error("Error retrieving all routes:", error);
    return [];
  }
};

/*
{
  "destination": "string",
  "departure": "string",
  "departure_time": "string",
  "price": 0,
  "seats": 0,
  "days": "string",
  "user": 0
}
*/
export const addRoute = async (newRoute, driverEmail) => {
  try {
    const driverRoutes = await getRoutes(driverEmail);
    const routeWithId = {
      ...newRoute,
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };
    const routeForApi = {
      destination: newRoute.destination,
      departure: newRoute.departure,
      price: newRoute.price,
      seats: newRoute.seats,
      days: "Monday-Friday",
      departureTime: newRoute.departureTime,
      user: driverEmail,
    };
    console.log("before inserting route", routeForApi);
    const response = await axios.post(LOCALHOST + "/api/routes/", routeForApi);
    console.log("✅ Route added successfully:", response.data);
    driverRoutes.push(response.data.message);
    await AsyncStorage.setItem(
      `${ROUTES_KEY}_${driverEmail}`,
      JSON.stringify(driverRoutes)
    );
  } catch (error) {
    console.error("Error adding route:", error);
  }
};

export const getRequests = async (passengerEmail) => {
  console.log("get requests");
  const requests = await axios.get(
    LOCALHOST + `/api/passager/${passengerEmail}/`
  );
  return requests.data.message;
};

export const getGlobalRequests = async () => {
  console.log("get blobal requests");
  const response = await axios.get(LOCALHOST + "/api/passager/");
  console.log("response", response.data);
  return response.data.message;
};

export const addRequest = async (newRequest) => {
  try {
    const passengerEmail = newRequest.passengerEmail;
    const passengerRequests = await getRequests(passengerEmail);
    const globalRequests = await getGlobalRequests();

    const requestWithId = {
      ...newRequest,
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };

    const requestForApi = {
      location: newRequest.location,
      destination: newRequest.destination,
      time: newRequest.time,
      email: newRequest.passengerEmail,
    };

    const response = await axios.post(
      LOCALHOST + "/api/passager/",
      requestForApi
    );
    passengerRequests.push(requestWithId);
    await AsyncStorage.setItem(
      `${REQUESTS_KEY}_${passengerEmail}`,
      JSON.stringify(passengerRequests)
    );
    globalRequests.push(requestWithId);
    await AsyncStorage.setItem(
      GLOBAL_REQUESTS_KEY,
      JSON.stringify(globalRequests)
    );
  } catch (error) {
    console.error("Error adding request:", error);
  }
};

export const deleteRequest = async (requestId) => {
    try {
        console.log("REQUEST ID", requestId);
        const response = await axios.delete(
        LOCALHOST + `/api/passager/${requestId}/`
        );
        console.log("✅ Request deleted successfully:", response.data);
    } catch (error) {
        console.error("Error deleting request:", error);
    }
}

export const deleteReservation = async (reservationId) => {
    try {
        const response = await axios.delete(
        LOCALHOST + `/api/bookings/${reservationId}/`
        );
        console.log("✅ Reservation deleted successfully:", response.data);
    } catch (error) {
        console.error("Error deleting reservation:", error);
    }
}

export const updateRequestStatus = async (requestId, status) => {
  try {
    console.log("status", status);
    if (status == "Rejected") {
      const response = await axios.put(
        LOCALHOST + `/api/route-reject/${requestId}/`,
        { status }
      );
      console.log("REJECT CALL")
      console.log("✅ Request deleted successfully:", response.data);
    } else {
        const email = await AsyncStorage.getItem("userEmail");
      const response = await axios.put(
        LOCALHOST + `/api/route-update/${requestId}/`,
        { status ,driver:email}
      );
      console.log("✅ Request updated successfully:", response.data);
    }
  } catch (error) {
    console.error("Error updating request status:", error);
  }
};

export const getReservations = async (passengerEmail) => {
  const response = await axios.get(
    LOCALHOST + `/api/bookings/${passengerEmail}/`
  );
  console.log("reservations", response.data);
  const reversations = response.data.message.map((reservation) => ({
    departure: reservation?.route?.departure,
    destination: reservation?.route?.destination,
    departureTime: reservation?.route?.departureTime,
    seatsReserved: reservation?.seats,
    days: reservation?.route?.days,
    ticketCode: reservation?.ticketCode,
    id: reservation?.id,
  }));
  console.log("reversations", reversations);
  return reversations;
};

export const getDriverReservations = async (driverEmail) => {
  const response =await axios.get(
    LOCALHOST + `/api/driver-bookings/${driverEmail}`
  );
    return response.data.message.map((reservation) => ({
        departure: reservation.route.departure,
        destination: reservation.route.destination,
        departureTime: reservation.route.departure_time,
        seatsReserved: reservation.seats,
        days: reservation.route.days,
        ticketCode: reservation.ticketCode,
        id: reservation.id,
        }));
};

export const getGlobalReservations = async () => {
  try {
    const reservationsJSON = await AsyncStorage.getItem(
      GLOBAL_RESERVATIONS_KEY
    );
    return reservationsJSON ? JSON.parse(reservationsJSON) : [];
  } catch (error) {
    console.error("Error retrieving global reservations:", error);
    return [];
  }
};

export const addReservation = async (newReservation) => {
  const apiRequest = {
    user: newReservation.passengerEmail,
    route: newReservation.routeId,
    seats: newReservation.seatsReserved,
    time: "Monday-Friday",
  };
  await axios.post(LOCALHOST + "/api/bookings/", apiRequest);
  /*try {
        const passengerEmail = newReservation.passengerEmail; 
        const driverEmail = newReservation.driverId; 
        
      
        const driverRoutes = await getRoutes(driverEmail);
    
        const updatedRoutes = driverRoutes.map((route) => {
            if (route.id === newReservation.routeId) {
                return {
                    ...route,
                    seats: parseInt(route.seats) - parseInt(newReservation.seatsReserved), 
                };
            }
            return route;
        });

     
        await AsyncStorage.setItem(`${ROUTES_KEY}_${driverEmail}`, JSON.stringify(updatedRoutes));

        const passengerReservations = await getReservations(passengerEmail);
        const driverReservations = await getDriverReservations(driverEmail);
        const globalReservations = await getGlobalReservations();

      
        const reservationWithQRCode = {
            ...newReservation,
            id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`, 
            ticketCode: `TICKET-${Math.random().toString(36).substr(2, 9).toUpperCase()}`, 
        };

      
        passengerReservations.push(reservationWithQRCode);
        await AsyncStorage.setItem(`${RESERVATIONS_KEY}_${passengerEmail}`, JSON.stringify(passengerReservations));

       
        driverReservations.push(reservationWithQRCode);
        await AsyncStorage.setItem(`${RESERVATIONS_KEY}_${driverEmail}`, JSON.stringify(driverReservations));

     
        globalReservations.push(reservationWithQRCode);
        await AsyncStorage.setItem(GLOBAL_RESERVATIONS_KEY, JSON.stringify(globalReservations));
    } catch (error) {
        console.error('Error adding reservation:', error);
    }*/
};

const USERS_KEY = "users";

export const getUsers = async () => {
  try {
    const usersJSON = await AsyncStorage.getItem(USERS_KEY);
    return usersJSON ? JSON.parse(usersJSON) : [];
  } catch (error) {
    console.error("Error retrieving users:", error);
    return [];
  }
};

export const addUser = async (newUser) => {
  try {
    const users = await getUsers();
    users.push(newUser);
    await AsyncStorage.setItem(USERS_KEY, JSON.stringify(users));
  } catch (error) {
    console.error("Error adding user:", error);
  }
};

export const findUser = async (email, password) => {
  try {
    const users = await getUsers();
    console.log("Stored Users:", users);
    console.log("Checking Email:", email, "Password:", password);

    return users.find(
      (user) =>
        user.email.trim().toLowerCase() === email.trim().toLowerCase() &&
        user.password === password
    );
  } catch (error) {
    console.error("Error finding user:", error);
    return null;
  }
};

export const logUsersToTerminal = async () => {
  try {
    const users = await getUsers();
    console.log("Stored Users:", users);
  } catch (error) {
    console.error("Error logging users:", error);
  }
};
