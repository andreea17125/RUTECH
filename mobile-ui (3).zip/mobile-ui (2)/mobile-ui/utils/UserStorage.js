import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { LOCALHOST } from './contants';

const USERS_KEY = 'users'; 


export const getUsers = async () => {
    try {
        const usersJSON = await AsyncStorage.getItem(USERS_KEY);
        return usersJSON ? JSON.parse(usersJSON) : [];
    } catch (error) {
        console.error('Error retrieving users:', error);
        return [];
    }
};

export const addUser = async (newUser) => {
    try {
        console.log("trying"    )
        const response = await axios.post(LOCALHOST+"/api/register/", newUser);
        console.log("✅ User registered successfully:", response.data);
    } catch (error) {
        if (error.response) {
            console.error("❌ Server Error:", {
                status: error.response.status,
                data: error.response.data,
                headers: error.response.headers,
            });
        } else if (error.request) {
            console.error("❌ No response received from server:", error.request);
        } else {
            console.error("❌ Error setting up request:", error.message);
        }
    }
};

export const findUser = async (email, password) => {
    /*try {
        const users = await getUsers();
        console.log('Stored Users:', users); 
        console.log('Checking Email:', email, 'Password:', password); 

        return users.find(
            (user) =>
                user.email.trim().toLowerCase() === email.trim().toLowerCase() && 
                user.password === password 
        );
    } catch (error) {
        console.error('Error finding user:', error);
        return null;
    }*/
   const response = await axios.post(LOCALHOST+ "/api/login/", { email, password });
    console.log("✅ User found successfully:", response.data);
    await AsyncStorage.setItem('userEmail', response.data.message.email);
   return response.data.message;
};

export const logUsersToTerminal = async () => {
    try {
        const users = await getUsers();
        console.log('Stored Users:', users); 
    } catch (error) {
        console.error('Error logging users:', error);
    }
};
