from django.contrib import admin
from .models import User
from .models import *
from .models import PassagerRouteBooking

# Register your models here.
admin.site.register(User)
admin.site.register(Route)
admin.site.register(PassagerRouteBooking)
admin.site.register(PassagerRouteRequest)
