from django.db import models
from rest_framework import serializers

class User(models.Model):
    roles = (
        ('passager', 'Passager'),
        ('driver', 'Driver'),
    )
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=128) 
    role = models.CharField(max_length=10, choices=roles, default='passager')
    login_tries = models.IntegerField(default=0)
    def __str__(self):
        return self.email
    

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['email', 'password', 'role',"id"]
        
class UserLoginSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['email', 'role',"id"]
        
        
#DRIVER

class Route(models.Model):
    destination = models.CharField(max_length=255)
    departure = models.CharField(max_length=255)
    departureTime = models.CharField(default="14:30"   , max_length=255)
    price = models.FloatField()
    seats = models.IntegerField()
    days = models.CharField(max_length=255) 
    user = models.ForeignKey(User, on_delete=models.CASCADE,default=1)
    def __str__(self):
        return f"{self.departure} to {self.destination} on {self.departureTime}"
    
class RouteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Route
        fields = ['destination', 'departure', 'departureTime', 'price', 'seats', 'days', 'id']
        
#PASAGER 

class PassagerRouteRequest(models.Model):
    location = models.CharField(max_length=255)
    destination = models.CharField(max_length=255)
    time = models.CharField(max_length=255)
    user = models.ForeignKey(User, on_delete=models.CASCADE,default=1)
    accepted = models.BooleanField(default=False)
    rejected = models.BooleanField(default=False)
    driver = models.ForeignKey(User,blank=True,null=True, on_delete=models.DO_NOTHING,related_name="driver",default=1)
    def __str__(self):
        return f"{self.location} to {self.destination} at {self.time}"
    
class PassagerRouteRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = PassagerRouteRequest
        fields = "__all__"
        

#BOOKING
class PassagerRouteBooking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    route = models.ForeignKey(Route, on_delete=models.SET_NULL,blank=True, null=True)
    time = models.CharField(max_length=255,default="")
    seats = models.IntegerField(default=1)
    ticket_code = models.TextField(default="")
    driver = models.ForeignKey(User, blank=True, null=True, on_delete=models.DO_NOTHING,related_name="driver_booking",default=1)
    def __str__(self):
        return f"{self.user} booked {self.route} at {self.time}"

        
class PassagerBookingSerializerDetailed(serializers.ModelSerializer):
    route = RouteSerializer()
    user = UserLoginSerializer()
    
    class Meta:
        model = PassagerRouteBooking
        fields = ['user', 'time',"id","seats","route","ticket_code"]
