from rest_framework import serializers



class UserCreateRequest(serializers.Serializer):
    email = serializers.EmailField(max_length=150, required=True)
    password = serializers.CharField(max_length=128, required=True)
    role = serializers.ChoiceField(choices=['passager', 'driver'], required=True)
    
    
class LoginUserRequest(serializers.Serializer):
    email = serializers.EmailField(max_length=150, required=True)
    password = serializers.CharField(max_length=128, required=True)
    
class RouteCreateRequest(serializers.Serializer):
    destination = serializers.CharField(max_length=255, required=True)
    departure = serializers.CharField(max_length=255, required=True)
    departureTime = serializers.CharField(required=True)
    price = serializers.FloatField(required=True)
    seats = serializers.IntegerField(required=True)
    days = serializers.CharField(max_length=255, required=True)
    user = serializers.CharField(required=True)
    
class PassagerRouteRequestCreateRequest(serializers.Serializer):
    location = serializers.CharField(max_length=255, required=True)
    destination = serializers.CharField(max_length=255, required=True)
    time = serializers.CharField(max_length=255, required=True)
    email = serializers.CharField(required=True)
    
    
class BookingRouteRequest(serializers.Serializer):
    user = serializers.IntegerField(required=True)
    route = serializers.IntegerField(required=True)
    seats = serializers.IntegerField(required=True)
    time = serializers.CharField(max_length=255, required=True)