from django.shortcuts import render
from rest_framework.decorators import APIView , api_view
from .requests import *
from drf_yasg.utils import swagger_auto_schema
from .models import *
from django.contrib.auth.hashers import make_password
from rest_framework.response import Response
from django.contrib.auth.hashers import check_password
from django.core.mail import send_mail
from django.conf import settings


#USER LOGIN CREATE
class UserView(APIView):
    @swagger_auto_schema(request_body=UserCreateRequest)
    def post(self,request):
        data = request.data 
        User.objects.create(email=data['email'], password=make_password(data['password']),role=data['role'])
        send_mail(
            'Welcome to RUTECH',
            'Thank you for registering to RUTECH.',
            settings.DEFAULT_FROM_EMAIL,
            [data['email']],
            fail_silently=False,
        )
        return Response({"message": "User created successfully"}, status=201)
   
class LoginView(APIView):
    @swagger_auto_schema(request_body=LoginUserRequest)
    def post(self,request):
        data = request.data
        try:
            user = User.objects.get(email=data['email'])
            password = data['password']
            if not check_password(password,user.password):
                user.login_tries += 1
                if(user.login_tries >= 3):
                    send_mail(
                        'Take care of your account',
                        'Your account was being accessed with an invalid password 3 times. Please change your password.',
                        settings.DEFAULT_FROM_EMAIL,
                        [data['email']],
                        fail_silently=False,
                    )
                user.save()
                return Response({"message": "Invalid credentials"}, status=401)
            user.login_tries = 0
            user.save()
            serialized_data = UserLoginSerializer(user).data
            return Response({"message":serialized_data}, status=200)
        except User.DoesNotExist:
            return Response({"message": "Invalid credentials"}, status=401)
        
        
#RUTE CREATE DE SOFER
class RouteView(APIView):
    @swagger_auto_schema(request_body=RouteCreateRequest)
    def post(self,request):
        data = request.data
        user = User.objects.get(email=data["user"])
        send_mail(
            'Route Confirmation',
            'Your route has been created successfully.',
            settings.DEFAULT_FROM_EMAIL,
            [user.email],
            fail_silently=False,
        )
        route = Route.objects.create(user_id=user.id,destination=data['destination'], departure=data['departure'], departureTime=data['departureTime'], price=data['price'], seats=data['seats'], days=data['days'])
        return Response({"message": RouteSerializer(route).data}, status=201)
    
    @swagger_auto_schema()
    def get(self,request):
        routes = Route.objects.all()
        serialized_data = RouteSerializer(routes, many=True).data
        return Response({"message":serialized_data}, status=200)
    def put(self,request):
        data = request.data
        try:
            route = Route.objects.get(id=data['id'])
            route.destination = data['destination']
            route.departure = data['departure']
            route.departureTime = data['departureTime']
            route.price = data['price']
            route.seats = data['seats']
            route.days = data['days']
            route.save()
            return Response({"message": "Route updated successfully"}, status=200)
        except Route.DoesNotExist:
            return Response({"message": "Route not found"}, status=404)     
        
@api_view(['DELETE'])
def delete_route(request, pk):
    try:
        route = Route.objects.get(id=pk)
        route.delete()
        return Response({"message": "Route deleted successfully"}, status=200)
    except Route.DoesNotExist:
        return Response({"message": "Route not found"}, status=404)
    
@api_view(['GET'])
def get_routes_for_driver_by_email(request, pk):
    try:
        user = User.objects.get(email=pk)
        routes = Route.objects.filter(user_id=user.id)
        serialized_data = RouteSerializer(routes, many=True).data
        return Response({"message":serialized_data}, status=200)
    except User.DoesNotExist:
        return Response({"message": "User not found"}, status=404)
#RUTE REQUEST DE PASAGER
class PassagerRouteRequestView(APIView):
    @swagger_auto_schema(request_body=PassagerRouteRequestCreateRequest)
    def post(self,request):
        data = request.data
        user_email = data["email"]
        user = User.objects.get(email=user_email)
        PassagerRouteRequest.objects.create(user_id=user.id,location=data['location'], destination=data['destination'], time=data['time'])
        send_mail(
            'Route Request Confirmation',
            'Your route request has been received.',
            settings.DEFAULT_FROM_EMAIL,
            [user.email],
            fail_silently=False,
        )
        return Response({"message": "Route request created successfully"}, status=201)
    def get(self,request):
        all_requests = PassagerRouteRequest.objects.filter(accepted=False,rejected=False)
        serialized_data = PassagerRouteRequestSerializer(all_requests, many=True).data
        return Response({"message":serialized_data}, status=200)

class PassagerRouteRequestWithPkView(APIView):
    @swagger_auto_schema()
    def get(self,request,pk):
        try:
            user = User.objects.get(email=pk)
            if user.role == "Passenger":
                route_request = PassagerRouteRequest.objects.filter(user_id=user.id)
            else:
                route_request = PassagerRouteRequest.objects.filter(accepted=False)
            serialized_data = PassagerRouteRequestSerializer(route_request,many=True).data
            return Response({"message":serialized_data}, status=200)
        except PassagerRouteRequest.DoesNotExist:
            return Response({"message": "Route request not found"}, status=404)
        
    def delete(self,request,pk):
        try:
            route_request = PassagerRouteRequest.objects.get(id=pk)
            route_request.delete()
            return Response({"message": "Route request deleted successfully"}, status=200)
        except PassagerRouteRequest.DoesNotExist:
            return Response({"message": "Route request not found"}, status=404)
        
@api_view(['PUT'])
def update_to_accepted(request, pk):
    try:
        route_request = PassagerRouteRequest.objects.get(id=pk)
        route_request.accepted = True
        route_request.driver = User.objects.get(email=request.data["driver"])
        route_request.save()
        ##TODO CHECK SITS
        PassagerRouteBooking.objects.create(driver_id=route_request.driver.id,user_id=route_request.user.id,time=route_request.time,seats=3)
        send_mail(
            'Route Request Accepted',
            'Your route request has been accepted.',
            settings.DEFAULT_FROM_EMAIL,
            [route_request.user.email],
            fail_silently=False,
        )
        return Response({"message": "Route request accepted successfully"}, status=200)
    except PassagerRouteRequest.DoesNotExist:
        return Response({"message": "Route request not found"}, status=404)
    
@api_view(['PUT'])
def update_to_reject(request, pk):
    try:
        route_request = PassagerRouteRequest.objects.get(id=pk)
        route_request.rejected = True
        route_request.save()
        send_mail(
            'Route Request Rejected',
            'Your route request has been Rejected.',
            settings.DEFAULT_FROM_EMAIL,
            [route_request.user.email],
            fail_silently=False,
        )
        return Response({"message": "Route request rejected successfully"}, status=200)
    except PassagerRouteRequest.DoesNotExist:
        return Response({"message": "Route request not found"}, status=404)
#BOOKING 

@api_view(['GET'])
def get_driver_revervations(request, pk):
    try:
        user = User.objects.get(email=pk)
        if user.role == "Driver":
            bookings = PassagerRouteBooking.objects.all()
            driver_boookings = []
            for booking in bookings:
                if booking.route != None:
                    driver = booking.route.user
                    if driver.id == user.id:
                        driver_boookings.append(booking)
            serialized_data = PassagerBookingSerializerDetailed(driver_boookings, many=True).data
            return Response({"message":serialized_data}, status=200)
        else:
            return Response({"message": "User is not a driver"}, status=403)
    except User.DoesNotExist:
        return Response({"message": "User not found"}, status=404)

class BookingRouteView(APIView):
    @swagger_auto_schema(request_body=BookingRouteRequest)
    def post(self,request):
        data = request.data
        user = User.objects.get(email=data["user"])
        route = Route.objects.get(id=data["route"])
        route.seats -= data["seats"]
        route.save()
        time = data["time"]
        seats = data["seats"]
        route_driver=route.user
        #generate random ticket unique code
        ticket_code = f"{user.id}-{route.id}-{seats}-{time}"
        send_mail(
            'Someone booked your route',
            'Your booking has been confirmed.',
            settings.DEFAULT_FROM_EMAIL,
            [route_driver.email],
            fail_silently=False,
        )
        PassagerRouteBooking.objects.create(user_id=user.id,route_id=route.id,time=time,seats=seats,ticket_code=ticket_code)
        send_mail(
            'Booking Confirmation',
            'Your booking has been confirmed.',
            settings.DEFAULT_FROM_EMAIL,
            [user.email],
            fail_silently=False,
        )
        return Response({"message": "Booking created successfully"},status=201)
    
class BookingRouteWithPkView(APIView):
    @swagger_auto_schema()
    def get(self,request,pk):
        try:
            user = User.objects.get(email=pk)
            booking = PassagerRouteBooking.objects.filter(user_id=user.id)
            serialized_data = PassagerBookingSerializerDetailed(booking,many=True).data
            return Response({"message":serialized_data}, status=200)
        except PassagerRouteBooking.DoesNotExist:
            return Response({"message": "Booking not found"}, status=404)
        
    def delete(self,request,pk):
        try:
            booking = PassagerRouteBooking.objects.get(id=pk)
            booking.delete()
            return Response({"message": "Booking deleted successfully"}, status=200)
        except PassagerRouteBooking.DoesNotExist:
            return Response({"message": "Booking not found"}, status=404)