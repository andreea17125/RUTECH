"""
URL configuration for ocsbackend project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
#swagger
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi
from django.conf import settings
from django.conf.urls.static import static
from UsersApp.views import *

schema_view = get_schema_view(
    openapi.Info(
        title="OCS API",
        default_version="v1",
        description="API documentation for OCS project",
        terms_of_service="https://www.google.com/policies/terms/",
    )
    ,
    public=True,
    permission_classes=(permissions.AllowAny,),
)
urlpatterns = [
    path("admin/", admin.site.urls),
    path("swagger/", schema_view.with_ui("swagger", cache_timeout=0), name="schema-swagger-ui"),
    path("api/driver-bookings/<str:pk>", get_driver_revervations, name="driver_booking_view"),
    path("api/register/", UserView.as_view(), name="user_view"),
    path("api/login/", LoginView.as_view(), name="login_view"),
    path("api/routes/", RouteView.as_view(), name="route_view"),
    path("api/passager/", PassagerRouteRequestView.as_view(), name="passager_route_request_view"),
    path("api/passager/<str:pk>/", PassagerRouteRequestWithPkView.as_view(), name="passager_route_request_detail_view"),
    path("api/bookings/", BookingRouteView.as_view(), name="booking_view"),
    path("api/bookings/<str:pk>/", BookingRouteWithPkView.as_view(), name="booking_detail_view"),
    path("api/route-update/<str:pk>/", update_to_accepted, name="update-route"),
    path("api/route-reject/<str:pk>/", update_to_reject, name="update-route"),
    path("api/route-for-driver/<str:pk>/", get_routes_for_driver_by_email, name="update-route"),
    path("api/delete-route/<str:pk>/", delete_route, name="delete-route"),
]
